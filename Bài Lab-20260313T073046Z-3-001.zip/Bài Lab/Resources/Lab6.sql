/* ======================================
   LAB 06 - FULL SQL SERVER SCRIPT
   - Drop DB if exists
   - Create DB
   - Create tables: student, tree (independent)
   - Insert sample data
   ====================================== */

-- 1) DROP DATABASE if exists
IF DB_ID('lab06_jdbc') IS NOT NULL
BEGIN
    ALTER DATABASE lab06_jdbc SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE lab06_jdbc;
END
GO

-- 2) CREATE DATABASE
CREATE DATABASE lab06_jdbc;
GO

USE lab06_jdbc;
GO

/* ======================================
   3) CREATE TABLE: student
   ====================================== */
CREATE TABLE dbo.student (
    student_id INT IDENTITY(1,1) PRIMARY KEY,
    student_name NVARCHAR(100) NOT NULL,
    gender NVARCHAR(10),
    gpa FLOAT CHECK (gpa >= 0 AND gpa <= 4.0)
);
GO

/* ======================================
   4) CREATE TABLE: tree (no foreign key)
   ====================================== */
CREATE TABLE dbo.tree (
    node_id INT IDENTITY(1,1) PRIMARY KEY,
    node_name NVARCHAR(100) NOT NULL,
    parent_id INT NULL,
    level INT NOT NULL
);
GO

/* ======================================
   5) INSERT SAMPLE DATA: student (5 rows)
   ====================================== */
INSERT INTO dbo.student (student_name, gender, gpa) VALUES
(N'Nguyễn Văn An', N'Nam', 3.2),
(N'Trần Thị Bình', N'Nữ', 3.6),
(N'Lê Hoàng Cường', N'Nam', 2.8),
(N'Phạm Ngọc Diệp', N'Nữ', 3.9),
(N'Vũ Minh Đức', N'Nam', 3.0);
GO

/* ======================================
   6) INSERT SAMPLE DATA: tree (tree structure)
   ====================================== */
INSERT INTO dbo.tree (node_name, parent_id, level) VALUES
-- Level 1 (Root)
(N'University', NULL, 1),

-- Level 2
(N'Faculty of IT', 1, 2),
(N'Faculty of Business', 1, 2),

-- Level 3
(N'Computer Science', 2, 3),
(N'Software Engineering', 2, 3),
(N'Accounting', 3, 3),
(N'Marketing', 3, 3),

-- Level 4
(N'Class SE01', 5, 4),
(N'Class SE02', 5, 4),
(N'Class CS01', 4, 4);
GO

/* ======================================
   7) CHECK DATA
   ====================================== */
SELECT * FROM dbo.student ORDER BY student_id;
SELECT * FROM dbo.tree ORDER BY level, parent_id, node_id;
GO
