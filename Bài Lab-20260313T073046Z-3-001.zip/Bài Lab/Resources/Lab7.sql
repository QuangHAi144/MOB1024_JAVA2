/* ===============================
   TẠO DATABASE
   =============================== */
IF DB_ID('lab06_jdbc') IS NULL
BEGIN
    CREATE DATABASE lab06_jdbc;
END
GO

USE lab06_jdbc;
GO

/* ===============================
   XÓA BẢNG NẾU ĐÃ TỒN TẠI
   =============================== */
IF OBJECT_ID('employee', 'U') IS NOT NULL
BEGIN
    DROP TABLE employee;
END
GO

/* ===============================
   TẠO BẢNG EMPLOYEE
   =============================== */
CREATE TABLE employee (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    salary FLOAT NOT NULL
);
GO

/* ===============================
   CHÈN DỮ LIỆU MẪU (5 BẢN GHI)
   =============================== */
INSERT INTO employee (name, salary) VALUES
(N'Nguyễn Văn A', 12000000),
(N'Trần Thị B', 15000000),
(N'Lê Văn C', 18000000),
(N'Phạm Thị D', 20000000),
(N'Hoàng Văn E', 22000000);
GO

/* ===============================
   KIỂM TRA DỮ LIỆU
   =============================== */
SELECT * FROM employee;
GO
